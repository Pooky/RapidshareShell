#include "test.h"
#include <iostream>

using namespace std;

test::test()
{
    cout << "hello";
}

test::~test()
{
    //dtor
}
