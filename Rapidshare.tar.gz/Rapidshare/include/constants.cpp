#include "constants.h"

Constants::Constants()
{
}

Constants::~Constants()
{
}

