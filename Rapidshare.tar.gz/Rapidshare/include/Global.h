#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <string>

namespace global
{
    const bool DEBUG = false;
    const int VERBOSE = 1;
	const std::string player = "totem";
} 


#endif // CONSTANTS_H
