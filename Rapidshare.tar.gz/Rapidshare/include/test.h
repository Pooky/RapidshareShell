#ifndef TEST_H
#define TEST_H


class test
{
    public:
        test();
        virtual ~test();
    protected:
    private:

};

#endif // TEST_H
